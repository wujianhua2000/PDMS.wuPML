using System;
using System.Collections;
using Aveva.ApplicationFramework;
using Aveva.ApplicationFramework.Presentation;
using Database = Aveva.Pdms.Database;

namespace Aveva.Pdms.Presentation.CoreConnectionsDiagramAddin
{
    /// <summary>
    /// This class is representing information about single SCCABLE element
    /// </summary>
    public class CableInfo
    {
        private string mCableName = string.Empty;
        private string mComponentName = string.Empty;
        private ArrayList mCores = new ArrayList();

        public CableInfo( Database.DbElement aCable )
        {
            //if given cable is valid in db:
            if( aCable.IsValid )
            {
                //get name of given cable
                mCableName = aCable.GetAsString( Database.DbAttributeInstance.NAMN );

                //get cable component name
                if( aCable.IsAttributeValid( Database.DbAttributeInstance.SPRE ) )
                {
                    Database.DbElement _spref = aCable.GetElement( Database.DbAttributeInstance.SPRE );
                    if( _spref.IsValid )
                        mComponentName = _spref.GetAsString( Database.DbAttributeInstance.NAMN );
                }
                
                Database.DbElement [] _cores = aCable.Members( Database.DbElementTypeInstance.SCCORE );
                
                //get informaton about cores
                foreach( Database.DbElement _core in _cores )
                {
                    CoreInfo _coreInf = new CoreInfo( _core );
                    mCores.Add( _coreInf );
                }
            }
        }

        /// <summary>
        /// gets name of represented cable
        /// </summary>
        public string CableName
        {
            get{    return mCableName;      }
        }

        /// <summary>
        /// gets name of component reference
        /// </summary>
        public string ComponentName
        {
            get{    return mComponentName;      }
        }

        /// <summary>
        /// gets array of object representing informations about cable cores
        /// </summary>
        public ArrayList CoreInfo
        {
            get{    return mCores;      }
        }

        /// <summary>
        /// gets number of cable cores
        /// </summary>
        public int CoreNo
        {
            get{    return mCores.Count;    }
        }

    }
}
