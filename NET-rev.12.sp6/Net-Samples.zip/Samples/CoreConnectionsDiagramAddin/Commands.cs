using System;
using System.Collections;
using Aveva.ApplicationFramework;
using Aveva.ApplicationFramework.Presentation;
using AxMicrosoft.Office.Interop.VisOcx;
using Visio = Microsoft.Office.Interop.Visio;
using Aveva.Marine.Diagrams;
using Database = Aveva.Pdms.Database;

namespace Aveva.Pdms.Presentation.CoreConnectionsDiagramAddin
{
    /// <summary>
    /// command class for Core Connections Diagram Addin toolbar
    /// </summary>
    public class CoreConnectionsDiagramToolbar : Command
    {
        public CoreConnectionsDiagramToolbar()
        {
            base.Key = CoreConnectionsDiagramAddin.CORE_CONN_TOOLBAR_CMD;
            base.Visible = false;
        }
    }

    /// <summary>
    /// class representing command to create new core connections diagram
    /// </summary>
    public class CoreConnectionsDiagramNew : Command
    {
        private bool mExecuting = false;
        private Hashtable mAddedCables = new Hashtable();

        public CoreConnectionsDiagramNew()
        {
            this.Key = CoreConnectionsDiagramAddin.CORE_CONN_NEW_CMD;
            this.Visible = true;
        }

        public override void Execute()
        {
            // if is already executing do nothing
            if( mExecuting )
                return;

            mExecuting = true;

            try
            {
                System.Windows.Forms.Control _activeCtrl = null;

                // find drawing for each core connections diagram should be generated
                if( WindowManager.Instance.MainForm.ActiveMdiChild != null )
                {
                    _activeCtrl = WindowManager.Instance.MainForm.ActiveMdiChild.ActiveControl;
                    if(_activeCtrl != null && !(_activeCtrl is AxDrawingControl))
                    {
                        foreach(System.Windows.Forms.Control ctrl in WindowManager.Instance.MainForm.ActiveMdiChild.ActiveControl.Controls)
                        {
                            if(ctrl is AxDrawingControl)
                            {
                                _activeCtrl = ctrl;
                                break;
                            }
                        }
                    }
                }
                ArrayList _cableList = new ArrayList();
                mAddedCables.Clear();
    
                // if drawing is found
                if( _activeCtrl != null && _activeCtrl is AxDrawingControl )
                {
                    // get active window
                    Visio.Window _actWindow = ((AxDrawingControl)_activeCtrl).Document.Application.ActiveWindow;
                    // get selection
                    Visio.Selection _selection = _actWindow.Selection;
                    _selection.IterationMode &= ~(int)Visio.VisSelectMode.visSelModeSkipSub;

                    // get cables from selection or from all document (if nothing is selected)
                    if( _selection.Count > 0 )
                    {
                        foreach( Visio.Shape _shape in _selection )
                            CheckAddShape( _shape, _cableList );
                    }
                    else
                    {
                        foreach( Visio.Page _page in ((AxDrawingControl)_activeCtrl).Document.Pages )
                            foreach( Visio.Shape _shape in _page.Shapes )
                                CheckAddShape( _shape, _cableList );
                    }
                }

                // execute "new diagram" command to create empty diagram
                if( CommandManager.Instance.Commands.ContainsKey( CoreConnectionsDiagramAddin.NEW_EMPTY_DIAGRAM_CMD ) )
                {
                    // get appropriate command and execute it
                    Command _newDiagCmd = CommandManager.Instance.Commands[ CoreConnectionsDiagramAddin.NEW_EMPTY_DIAGRAM_CMD ];
                    _newDiagCmd.Execute();

                    // if new diagram creation succeded draw core connections schema
                    if( _newDiagCmd.Value != null && _newDiagCmd.Value is AxDrawingControl )
                    {
                        CoreConnectionsDiagram _diag = new CoreConnectionsDiagram( (AxDrawingControl)_newDiagCmd.Value );
                        _diag.DrawSchema( _cableList );
                    }
                }
            }
            finally
            {
                mExecuting = false;
            }
        }

        /// <summary>
        /// This method is checking if given shape is cable shape or is group containing cable shapes
        /// and adds found cables to given list
        /// </summary>
        /// <param name="aShape">shape to examine</param>
        /// <param name="aList">list of shapes to update</param>
        private void CheckAddShape( Visio.Shape aShape, ArrayList aList )
        {
            // try only for defined shapes
            if( VmdElement.IsDefined( aShape ) )
            {
                VmdElement _vmdElem = VmdObject.GetElement( aShape );
                // if shape is a cable shape check if it is valid in db
                if( _vmdElem != null && _vmdElem is VmdCable )
                {
                    Database.DbElement _dbElem = Database.DbElement.GetElement( VmdObject.GetRefNumber( aShape ) );

                    // if cable is valid in db and not already added add it to list
                    if( _dbElem.IsValid && ! mAddedCables.ContainsKey( _dbElem.GetAsString( Database.DbAttributeInstance.NAME ) ) )
                    {
                        aList.Add( _dbElem );
                        mAddedCables.Add( _dbElem.GetAsString( Database.DbAttributeInstance.NAME ), null );
                    }
                }
            }

            // if given shape is a group examine all containing shapes
            if( aShape.Type == (short)Visio.VisShapeTypes.visTypeGroup )
                foreach( Visio.Shape _subShape in aShape.Shapes )
                    CheckAddShape( _subShape, aList );
        }
    }
}
